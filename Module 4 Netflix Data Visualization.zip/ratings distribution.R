# Load libraries
library(ggplot2)
library(dplyr)

# Read data
netflix_data <- read.csv("Netflix_shows_movies.csv")

# Plot ratings distribution
ggplot(netflix_data, aes(x = rating)) +
  geom_bar(fill = "steelblue") +
  labs(title = "Distribution of Content Ratings (R)", x = "Rating", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save the plot
ggsave("ratings_distribution_R.png", width = 8, height = 6)
